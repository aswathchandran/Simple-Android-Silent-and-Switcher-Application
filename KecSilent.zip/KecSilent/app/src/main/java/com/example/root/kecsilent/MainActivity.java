package com.example.root.kecsilent;

import android.content.Context;
import android.media.AudioManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.Calendar;

import static android.content.Context.*;

public class MainActivity extends AppCompatActivity {

    Button b1,b2,b3;
    AudioManager audiomanager;
    Calendar c;
    int hr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1 = (Button) findViewById(R.id.normal);
        b2 = (Button) findViewById(R.id.silent);
        b3 = (Button) findViewById(R.id.vibrate);
        audiomanager= (AudioManager) getSystemService(AUDIO_SERVICE);
        c=Calendar.getInstance();
        c.getTime();
        //hr=c.getTime();

        b1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // TODO Auto-generated method stub
                audiomanager.setRingerMode(AudioManager.RINGER_MODE_NORMAL);
                Toast.makeText(getApplicationContext(),"Normal",Toast.LENGTH_SHORT).show();
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // TODO Auto-generated method stub
                audiomanager.setRingerMode(AudioManager.RINGER_MODE_SILENT);
                Toast.makeText(getApplicationContext(),"Silent",Toast.LENGTH_SHORT).show();
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                // TODO Auto-generated method stub
                audiomanager.setRingerMode(AudioManager.RINGER_MODE_VIBRATE);
                Toast.makeText(getApplicationContext(),"Vibration",Toast.LENGTH_SHORT).show();
            }
        });



    }
}
